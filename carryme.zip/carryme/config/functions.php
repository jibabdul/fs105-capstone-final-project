<?php

function validateData($value) {
    $value = trim($value);
    $value = stripslashes($value);
    $value = htmlspecialchars($value);
    return $value;
}

function isNotLoggedIn(){
    if(isset($_COOKIE['userId']) || isset($_COOKIE['isLoggedIn'])){
        header("Location: " . SITE_URL );
        
        
    }
}

function isLoggedIn(){
    if(!isset($_COOKIE['userId']) || !isset($_COOKIE['isLoggedIn'])){
        header("Location: " . SITE_URL . "login.php");
        
    }
}
?>