<?php

define("SITE_NAME", "CarryMe", true);
define("SITE_URL", "http://localhost:8888/carryme/", true);

?>