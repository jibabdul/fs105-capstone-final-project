<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';


if (isset($_GET['id'])) {
	$user = DB::query("SELECT * FROM users WHERE users_id=%i", $_GET['id']);
	foreach ($user as $userResults) {
		$userDisplayName = $userResults['users_displayname'];
	}
}

if (isset($_GET['id'])) {
	$profile = '<a href=' .  SITE_URL . 'editprofile.php?id=' . $_GET['id'] . ' class="theme_button"> ' .   $userDisplayName . '</a>';
	$login = '<a href=' . SITE_URL . 'logout.php class="theme_button">Log Out</a>';
	$getId = "?id=";
} else {
	$getId = "";
	$login = "<a href='#myModal' class='theme_button' data-toggle='modal'>Login</a>";
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<title>CarryMe - About Us</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>


	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">
				<i class="rt-icon2-cross2"></i>
			</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform form-inline" action="./">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class="theme_button">Search</button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls with_padding">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--		
		<ul>
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div>
	<!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<section class="page_toplogo table_section ls mainpge_toplogo section_padding_25">
				<div class="container">
					<div class="row">
						<div class="col-sm-4 col-lg-3 pull-left">
							<a href="./" class="logo">
								<img src="images/carryme-logo-03.png" alt="">
							</a>
						</div>
						
					</div>
				</div>
		</div>
		</section>

		<header class="page_header header_darkgrey ms toggle_menu_left">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<!-- main nav start -->
						<nav class="mainmenu_wrapper">
							<ul class="mainmenu nav sf-menu">
								<li>
									<a href="<?php echo SITE_URL . "index.php" . $getId . $_GET['id']; ?>">Home</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "listing.php" . $getId . $_GET['id'];  ?>">Pickup</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "about.php" . $getId . $_GET['id']; ?>">About Us</a>
								</li>

								<!-- contacts -->
								<li>
									<a href="<?php echo SITE_URL . "contact.php" . $getId . $_GET['id']; ?>">Contact us</a>
								</li>

								<!-- eof contacts -->
							</ul>
						</nav>
						<!-- eof main nav -->
					</div>
					<!-- eof .header_mainmenu -->
					<div class="col-md-3 text-right">
						<span class="toggle_menu">
							<span></span>
						</span>
						<span><?php echo $profile ?></span>
						<span><?php echo $login ?></span>
						<!-- <a href="#myModal" class="theme_button" data-toggle="modal">Login</a> -->
					</div>
				</div>
			</div>
		</header>
		<!-- Login Modal HTML -->
		<div id="myModal" class="modal fade">
			<div class="modal-dialog modal-login">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Login to</h4><br>
						<img src="images/carryme-logo-03.png" alt=""><br>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<form>
							<div class="form-group">
								<i class="fa fa-user"></i>
								<input type="text" class="form-control" placeholder="Email" id="email" name="email">
							</div>
							<div class="form-group">
								<i class="fa fa-lock"></i>
								<input type="password" class="form-control" placeholder="Password" id="password" name="password">
							</div>
							<div class="form-group">
								<input type="submit" class="btn btn-primary btn-block btn-lg" name="signIn" id="signIn" value="Login">
							</div>
						</form>
						<span id="required"></span>
					</div>
					<div class="modal-footer">
						<a href="<?php echo SITE_URL . "requestpassword.php" ?>">Forgot Password?</a>
					</div>
				</div>
			</div>
		</div>
		<section class="page_breadcrumbs template_breadcrumbs ds parallax">
			<div class="container-fluid">
				<div class="row">
					<div class="breadcrumbs_wrap col-lg-5 col-md-7 col-sm-8 text-right to_animate" data-animation="fadeInLeftLong">
						<div class="to_animate" data-animation="fadeInLeft" data-delay="500">
							<h2>About us</h2>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="ls section_padding_top_100">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="framed-heading">
							<h2 class="section_header">
								We are
								<span class="highlight2">CarryMe</span>
								<br>
								<span class="small">Transport Company</span>
							</h2>
						</div>
						<p class="bottommargin_40">
							Etiam blandit blandit metus, at lacinia turpis volutpat a. Etiam tortor velit, viverra nec est sed, semper facilisis turpis. Nam non mattis arcu. Proin vehicula scelerisque sagittis. Fusce convallis viverra mi, et vulputate nunc tempor vitae. Cras eget
							ornare arcu, eget venenatis arcu.
						</p>
						<h3 class="entry-title">Frequently Asked questions</h3>

						<div class="panel-group" id="accordion1">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion1" href="#collapse1" class="collapsed">
											<!-- <i class="rt-icon2-bubble highlight"></i> -->
											How quickly can i start transporting ?
										</a>
									</h4>
								</div>
								<div id="collapse1" class="panel-collapse collapse">
									<div class="panel-body">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem facere doloremque ut dolores laudantium nihil at, repudiandae est numquam fuga tempora totam sequi quidem saepe officiis sint beatae, magni fugit.
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion1" href="#collapse2" class="collapsed">
											<!-- <i class="rt-icon2-bubble highlight"></i> -->
											where are your consultants based ?
										</a>
									</h4>
								</div>
								<div id="collapse2" class="panel-collapse collapse">
									<div class="panel-body">
										Morbi mi justo, ultrices nec turpis eget, dictum volutpat ex. In sit amet ante sollici, ultrices erat vitae, dapibus risus. Donec finibus est ac lacus sollicitudin, non maler neque commodo. Morbi non blandit massa, vitae placerat libero.
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion1" href="#collapse3" class="collapsed">
											<!-- <i class="rt-icon2-bubble highlight"></i> -->
											what is the fee of your service ?
										</a>
									</h4>
								</div>
								<div id="collapse3" class="panel-collapse collapse">
									<div class="panel-body">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit. At nobis omnis delectus, asperiores quo obcaecati et iste corporis necessitatibus tempora aspernatur doloribus. Ut deleniti commodi dicta distinctio sit enim quidem!
									</div>
								</div>
							</div>

						</div>

					</div>
					<div class="col-md-6 text-center bottommargin_0">
						<img class="top-overlap-small" src="images/person.png" alt="" />
					</div>
				</div>
			</div>
		</section>

		<section class="ls ms section_padding_100 intro_section4">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-7">
						<div class="row columns_padding_60 columns_margin_bottom_30 columns_margin_top_30">

							<div class="col-sm-6 to_animate" data-animation="pullDown">
								<div class="teaser text-center">
									<div class="teaser_icon size_big">
										<i class="flaticon-house highlight2"></i>
									</div>
									<h4>
										<a href="service-single.html">Residential / Local</a>
									</h4>
									<p>
										We offer packing equipment, packing instructions and tips as well as labor and support to make your move efficient and stress free.
									</p>
								</div>
							</div>

							<div class="col-sm-6 to_animate" data-animation="pullDown">
								<div class="teaser text-center">
									<div class="teaser_icon size_big">
										<i class="flaticon-package highlight2"></i>
									</div>
									<h4>
										<a href="service-single.html">box delivery</a>
									</h4>
									<p>
										We have all the packing supplies, including boxes specifically for clothes, pictures and dishes as well as packing tape and wrap.
									</p>
								</div>
							</div>

							<div class="col-sm-6 to_animate" data-animation="pullDown">
								<div class="teaser text-center">
									<div class="teaser_icon size_big">
										<i class="flaticon-truck highlight2"></i>
									</div>
									<h4>
										<a href="service-single.html">Commercial/Office</a>
									</h4>
									<p>
										Whether it’s just moving floors or across the country, our movers are experienced and trained to effectively handle, transport, and install
									</p>
								</div>
							</div>

							<div class="col-sm-6 to_animate" data-animation="pullDown">
								<div class="teaser text-center">
									<div class="teaser_icon size_big">
										<i class="flaticon-trolley highlight2"></i>
									</div>
									<h4>
										<a href="service-single.html">Loading/Unloading</a>
									</h4>
									<p>
										If you’re looking to save money, we allow our customers to rent the moving truck, and we’ll load and/or unload your belongings.
									</p>
								</div>
							</div>

						</div>
					</div>
					<div class="col-md-5 bg_overlay cs to_animate" data-animation="fadeInRightLong">
						<div>
							<div class="to_animate" data-animation="fadeInRight" data-delay="500">
								<div class="framed-heading side-frame">
									<h2 class="section_header">
										Our
										<br> services
									</h2>
								</div>
							</div>
							<div class="to_animate" data-animation="fadeInRight">
								<p>
									In et scelerisque enim. Etiam nec mauris in elit pellentesque suscipit. Vivamus bibendum tincidu velit, et aliquam elit dictum nec. Pellentesque libero elit, blandit sit amet erat consectetur, placerat lobortis tellus.
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="ls section_padding_100 columns_margin_bottom_30 section_padding_bottom_75">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-sm-6 text-center">
						<div class="teaser counter-teaser media inline-block text-left">
							<div class="media-left media-middle">
								<div class="teaser_icon highlight2 size_big">
									<i class="flaticon-like"></i>
								</div>
							</div>
							<div class="media-body media-middle">
								<h3 class="counter" data-from="0" data-to="8042" data-speed="1800">0</h3>
								<p class="small-text">clients trust in us</p>
							</div>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 text-center">
						<div class="teaser counter-teaser media inline-block text-left">
							<div class="media-left media-middle">
								<div class="teaser_icon highlight2 size_big">
									<i class="flaticon-truck-1"></i>
								</div>
							</div>
							<div class="media-body media-middle">
								<h3 class="counter" data-from="0" data-to="10932" data-speed="1800">0</h3>
								<p class="small-text">Km for year</p>
							</div>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 text-center">
						<div class="teaser counter-teaser media inline-block text-left">
							<div class="media-left media-middle">
								<div class="teaser_icon highlight2 size_big">
									<i class="flaticon-trolley"></i>
								</div>
							</div>
							<div class="media-body media-middle">
								<h3 class="counter" data-from="0" data-to="5721" data-speed="1800">0</h3>
								<p class="small-text">Tons of goods</p>
							</div>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 text-center">
						<div class="teaser counter-teaser media inline-block text-left">
							<div class="media-left media-middle">
								<div class="teaser_icon highlight2 size_big">
									<i class="flaticon-percentage"></i>
								</div>
							</div>
							<div class="media-body media-middle">
								<h3 class="counter" data-from="0" data-to="689" data-speed="1800">0</h3>
								<p class="small-text">Held shares</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="cs section_padding_top_100 section_padding_bottom_75 parallax page_testimonials columns_margin_bottom_30">
			<div class="container">
				<div class="row">
					<div class="col-lg-4">
						<div class="framed-heading side-frame">
							<h2 class="section_header">
								Clients
								<br> say
							</h2>
						</div>
						<p class="leftmargin_50">
							Suspendisse quis scelerisque sapien. Proin pulvin porttitor metus vitae tincidunt. Pelle habitant morbi tristique senectus netus.
						</p>
					</div>
					<div class="col-lg-8">
						<div class="owl-carousel testimonials-carousel margin_0" data-responsive-lg="2" data-responsive-md="2" data-responsive-sm="2" data-responsive-xs="1" data-nav="true" data-nav-container=".testimonials-carousel-nav">
							<blockquote class="margin_0">
								Fusce lacinia, urna nec molestie congue, ante justo hendrerit risus, quis suscipit sapien leo et est. Fusce nec suscipit risus.

								<div class="item-meta">
									<h5 class="highlight2">Sue Spencer</h5>
									<p>Manager</p>
								</div>
							</blockquote>

							<blockquote class="margin_0">
								Sed vitae ex quis tellus consectet accumsan et non sem. Sed consectetur at lacus ac vehicula. Maecenas eleifend.

								<div class="item-meta">
									<h5 class="highlight2">Allen Peterson</h5>
									<p>Director</p>
								</div>
							</blockquote>

							<blockquote class="margin_0">
								Fusce lacinia, urna nec molestie congue, ante justo hendrerit risus, quis suscipit sapien leo et est. Fusce nec suscipit risus.

								<div class="item-meta">
									<h5 class="highlight2">Sue Spencer</h5>
									<p>Manager</p>
								</div>
							</blockquote>

							<blockquote class="margin_0">
								Sed vitae ex quis tellus consectet accumsan et non sem. Sed consectetur at lacus ac vehicula. Maecenas eleifend.

								<div class="item-meta">
									<h5 class="highlight2">Allen Peterson</h5>
									<p>Director</p>
								</div>
							</blockquote>

						</div>
					</div>
				</div>
			</div>
			<div class="container-fluid testimonials-carousel-nav owl-nav"></div>
		</section>

		<section class="ls section_padding_top_100 section_padding_bottom_75">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<div class="framed-heading bottommargin_15">
							<h2 class="section_header">
								Our CarryMe Team
							</h2>
						</div>
						<div class="owl-carousel team-carousel topmargin_60 bottommargin_0" data-responsive-lg="4" data-responsive-md="3" data-responsive-sm="2" data-nav="true">

							<div class="thumbnail">
								<img src="images/carrymeteam/7.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Millie Clarke</p>
									</h3>
									<p>Director</p>
								</div>
							</div>

							<div class="thumbnail">
								<img src="images/carrymeteam/8.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Dominic Ramos</p>
									</h3>
									<p>Assistant Director</p>
								</div>
							</div>

							<div class="thumbnail">
								<img src="images/carrymeteam/3.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Clayton Lyons</p>
									</h3>
									<p>Manager</p>
								</div>
							</div>
							<div class="thumbnail">
								<img src="images/carrymeteam/1.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Mitchell Jackson</p>
									</h3>
									<p>Own Carrier</p>
								</div>
							</div>
							<div class="thumbnail">
								<img src="images/carrymeteam/2.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Isabella Brady</p>
									</h3>
									<p>Administrator</p>
								</div>
							</div>
							<div class="thumbnail">
								<img src="images/carrymeteam/4.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Jerry Stewart</p>
									</h3>
									<p>Own Carrier</p>
								</div>
							</div>

							<div class="thumbnail">
								<img src="images/carrymeteam/5.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Anthony Pierce</p>
									</h3>
									<p>Own Carrier</p>
								</div>
							</div>

							<div class="thumbnail">
								<img src="images/carrymeteam/6.jpg" alt="">
								<div class="caption with_border">
									<h3>
										<p>Marie Knight</P>
									</h3>
									<p>Own Carrier</p>
								</div>
							</div>
						</div>
						<!-- <div class="team-carousel-nav owl-nav fullwidth-nav"></div> -->
					</div>

				</div>
			</div>
		</section>


		<section class="ls section_padding_top_75 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<div class="framed-heading bottommargin_15">
								<h2 class="section_header">
									Our Clients
								</h2>
							</div>
							<p>
								Phasellus efficitur, massa posuere ultricies faucibus, purus ante dapibus tellus, ut venenatis massa magna ut justo. Nunc in molestie lectus eleifend.
							</p>
						</div>
					</div>
					<div class="row topmargin_30">
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/01.png" alt="" />
							</a>
						</div>
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/02.png" alt="" />
							</a>
						</div>
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/03.png" alt="" />
							</a>
						</div>
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/04.png" alt="" />
							</a>
						</div>
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/05.png" alt="" />
							</a>
						</div>
						<div class="col-md-2 col-sm-4 col-xs-6 text-center to_animate partner-link" data-animation="pullUp">
							
								<img src="./images/partners/06.png" alt="" />
							</a>
						</div>
					</div>
				</div>
			</section>

			<section class="cs section_padding_40">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://api.whatsapp.com/send?phone=6596601666&text=Hi,%20I%20want%20to%20know%20more%20about%20CarryMe." target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="fa fa-whatsapp"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Any question?</span>
									<br> Whatsapp Us!
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://www.google.com/maps/@1.2809363,103.8186308,17z" target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-house"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">258 Henderson Road</span>
									<br> Singapore, Singapore
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="media inline-block small-teaser text-left teaser-link">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round dark">
										<i class="flaticon-paper-plane"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Mon-Sat</span>
									<br> 09:00-21:00
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="mailto:carryme@email.com">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-envelope"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Send your mail at</span>
									<br>carryme@email.com
								</span>
							</a>
						</div>
					</div>
				</div>
			</section>


			<footer class="page_footer ds ms color section_padding_75 columns_margin_bottom_30">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-12">
							<img src="images/logo-light-04.png" alt="">
						</div>
					</div>
				</div>
			</footer>

			<section class="page_copyright cs main_color2 section_padding_15 columns_margin_0">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<p>&copy; CarryMe 2020
							</p>
						</div>
					</div>
				</div>
			</section>

		</div>
		<!-- eof #box_wrapper -->
		
 
	</div>
	<!-- eof #canvas -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script>
		$(document).ready(function() {
			$("form").submit(function(e) {
				e.preventDefault(e);
			});

			$("#signIn").click(function() {
				var email = $("#email").val();
				var password = $("#password").val();
				var signIn = $("#signIn").val();

				$.ajax({
					url: 'ajax-login.php', //action
					method: 'POST', //method
					data: {
						email: email,
						password: password,
						signIn: signIn
					},
					success: function(data) {

						if (data >= 0) {

							window.location.href = "<?php echo SITE_URL . 'editprofile.php?id=' ?>" + data;

						} else {
							$("#required").text(data);
							$("#password").val("");
						}




					}
				});
			});
		});
	</script>
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>


</body>

</html>