-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 23, 2021 at 02:39 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carryme`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_weight` decimal(10,2) NOT NULL,
  `item_length` decimal(10,2) NOT NULL,
  `item_location` varchar(100) NOT NULL,
  `item_destination` varchar(100) NOT NULL,
  `item_date` date NOT NULL,
  `item_time` time NOT NULL,
  `item_pickup` varchar(100) NOT NULL,
  `item_delivery` varchar(100) NOT NULL,
  `item_setfee` decimal(10,2) NOT NULL,
  `item_remark` text NOT NULL,
  `item_img` varchar(100) DEFAULT NULL,
  `users_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_weight`, `item_length`, `item_location`, `item_destination`, `item_date`, `item_time`, `item_pickup`, `item_delivery`, `item_setfee`, `item_remark`, `item_img`, `users_id`) VALUES
(10, 'ioi', '111.00', '11.00', '1231', 'ang mo kio', '2021-07-03', '14:44:00', '1', '1', '10.10', 'sss', 'uploads/148492233660f7c249e449f2.86172833.jpg', 22),
(11, 'osman', '121.11', '112.10', 'hougang st 22', 'bishan ave 1', '2021-07-10', '14:53:00', '1', '0', '10.30', 'tesst', 'uploads/199276434460f7c6545bec43.99294521.jpg', 22),
(12, 'table', '100.00', '10.00', 'bedok ave 2', 'jurong ave 3', '2021-07-17', '20:07:00', '1', '0', '30.00', 'na', 'uploads/112555782560f95fb39487a7.67856101.jpg', 22),
(13, 'chair', '2.00', '50.00', '24 bukit batok ave 2', 'yishun', '2021-07-24', '17:15:00', '1', '0', '10.00', 'no lift landing', 'uploads/180456208660fa88d17b9261.70419406.jpg', 22),
(14, 'guitar', '4.00', '1.00', '231 jurong ave 9', '201 simei ave 1', '2021-07-10', '12:23:00', '1', '1', '20.00', 'urgent', 'uploads/22779172660fac2e65bd887.12252177.jpg', 27);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `msg_id` int(11) NOT NULL,
  `msg_created` timestamp NULL DEFAULT NULL,
  `msg_item_id` int(11) NOT NULL,
  `msg_owner_id` int(11) NOT NULL,
  `msg_carrier_id` int(11) NOT NULL,
  `msg_itemtext` text,
  `msg_ownertext` text,
  `msg_carriertext` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL,
  `users_email` varchar(256) NOT NULL,
  `users_password` varchar(256) NOT NULL,
  `email_verification_link` text NOT NULL,
  `users_displayname` varchar(256) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `users_name` varchar(256) DEFAULT NULL,
  `users_contact` int(11) DEFAULT NULL,
  `users_img` varchar(100) DEFAULT NULL,
  `users_address` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `users_email`, `users_password`, `email_verification_link`, `users_displayname`, `email_verified_at`, `users_name`, `users_contact`, `users_img`, `users_address`) VALUES
(15, 'muhd.nasiruddin2014@gmail.com', '$2y$10$.MWPl0NPRYlREu5ifww.G.qyS9JGTv0mnl4uQ5/P3yAuFs0xVNWt2', '83423dd6e559d980d36bdb39298ca947693', NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'satriamillenium@yahoo.com.sg', '$2y$10$8BWYv7T9LI91Le95gLBr6ONBrswQXhJmRtaLco1ohVJUSZyqHSHNi', '2a7c30d333c34b2d5d199f16e30a0b238324', 'sleepy', '2021-07-19 08:12:57', 'haha', 96601666, 'uploads/49223326660fab53e217374.28161428.jpg', ''),
(25, 'noorhanah.ismail@gmail.com', '$2y$10$BEil3ue15FXj.sGfICtZJu02Lun8C6ub1/PrGHL9ZhuxC40BN2fca', 'e73ff3d58a992554db21b37ada1de2a43931', NULL, '2021-07-22 03:42:02', NULL, NULL, 'uploads/2874673160f95c1cde2060.23559483.jpg', NULL),
(27, 'osman.ahmad06@gmail.com', '$2y$10$LRB5luOvqOcliR3WiXI9z.Rs3EmL/D.LWbFE9yoW7CPVdXutQ6kMm', '7538a7fbc99bf787c07e70cf30b40b938958', 'zombie', '2021-07-22 04:03:40', 'bob', 82452045, 'uploads/135254613260fac2481302e3.61622654.jpg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `msg_item_id` (`msg_item_id`),
  ADD KEY `msg_carrier_id` (`msg_carrier_id`),
  ADD KEY `msg_owner_id` (`msg_owner_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `users_id` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`);

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `msg_carrier_id` FOREIGN KEY (`msg_carrier_id`) REFERENCES `users` (`users_id`),
  ADD CONSTRAINT `msg_item_id` FOREIGN KEY (`msg_item_id`) REFERENCES `items` (`item_id`),
  ADD CONSTRAINT `msg_owner_id` FOREIGN KEY (`msg_owner_id`) REFERENCES `users` (`users_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
