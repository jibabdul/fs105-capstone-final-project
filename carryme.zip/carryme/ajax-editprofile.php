<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

$name = $email = $password = $cfmPassword = "";

if(isset($_POST['addUser'])){
    if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['cfmPassword'])){
        echo "Please fill up all required fields.";
    }else{
        $name = validateData($_POST['name']);
        $email = validateData($_POST['email']);
        $password = validateData($_POST['password']);
        $cfmPassword = validateData($_POST['cfmPassword']);
        if($password != $cfmPassword){
            echo "Password mismatch. Please enter the same password.";
        }else{
            DB::$success_handler = 'my_success_handler';
            function my_success_handler() {
                echo "User added successfully!";
            }

            DB::insert("users", [
                'users_name' => strtolower($name),
                'users_email' => strtolower($email),
                'users_password' => password_hash($password, PASSWORD_DEFAULT)
            ]);
        }
    }
}else{
    header("Location: " . SITE_URL . "insert.php");
}
?>