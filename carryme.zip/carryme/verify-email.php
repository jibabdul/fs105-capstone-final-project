<?php


if(isset($_GET['key']) && $_GET['token']) {
include 'config/db.php';
include 'config/config.php';    

$email = $_GET['key'];
$token = $_GET['token'];
// $userQuery = DB::query("SELECT * FROM users WHERE users_email=%s", $email);
// $userCount = DB::count();
$userQuery = DB::query("SELECT * FROM `users` WHERE `email_verification_link`='".$token."' and `users_email`='".$email."';");
$userCount = DB::count();
   if($userCount == 1){
    $timeStamp = date('Y-m-d H:i:s');
    foreach ($userQuery as $row) {
      $dbEmail = $row['users_email'];
      if($dbTimeStamp == NULL ){
        DB::update("users", [
        'email_verified_at' => $timeStamp,
        ], "users_email=%s", $dbEmail);
        header("Location: " . SITE_URL . "login.php?success-verified=1");
        $msg = "Congratulations! Your email has been verified.";
      } else {
        header("Location: " . SITE_URL . "login.php?already-verified=1");
        $msg = "You have already verified your account with us";
      }
    }
  } else {
    header("Location: " . SITE_URL . "login.php?not-verified=1");
    $msg = "Email not registered";
  }
}else {
  header("Location: " . SITE_URL . "login.php?error-verified=1");
  $msg = "Danger! Your something goes to wrong.";
}



//   if (mysqli_num_rows($query) > 0) {
//     $row= mysqli_fetch_array($query);
//     if($row['email_verified_at'] == NULL){
//         mysqli_query($conn,"UPDATE users set email_verified_at ='" . $timeStamp . "' WHERE email='" . $email . "'");
//         $msg = "Congratulations! Your email has been verified.";
//     }else{
//         $msg = "You have already verified your account with us";
//     }
     
//   } else {
//     $msg = "This email has been not registered with us";
//   }
// } else {
//   $msg = "Danger! Your something goes to wrong.";
// }
// 
// $query = DB::query("SELECT * FROM `users` WHERE `email_verification_link`='".$token."' and `email`='".$email."';");
// $timeStamp = date('Y-m-d H:i:s');

//   if (mysqli_num_rows($query) > 0) {
//     $row= mysqli_fetch_array($query);
//     if($row['email_verified_at'] == NULL){
//         mysqli_query($conn,"UPDATE users set email_verified_at ='" . $timeStamp . "' WHERE email='" . $email . "'");
//         $msg = "Congratulations! Your email has been verified.";
//     }else{
//         $msg = "You have already verified your account with us";
//     }
     
//   } else {
//     $msg = "This email has been not registered with us";
//   }
// } else {
//   $msg = "Danger! Your something goes to wrong.";
// }
?>

