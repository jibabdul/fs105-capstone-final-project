<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

$email = $password = $error = $loginSuccess = "";


  if (isset($_POST['signIn'])) {
	  if (empty($_POST['email']) || empty($_POST['password'])) {
		  echo "Please enter your email & password";
	  } else {
		  $email = validateData($_POST['email']);
		  $password = validateData($_POST['password']);

		  //validate if email is legit
		  if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
			  //is a valid email address
			  $userQuery = DB::query("SELECT * FROM users WHERE users_email=%s", $email);
			  $userCount = DB::count();
			  if ($userCount == 1) { //user exist
				  foreach ($userQuery as $userResult) {
					  $dbId = $userResult['users_id'];
					  $dbPassword = $userResult['users_password'];
					  $dbVerified = $userResult['email_verified_at'];
				  }
				  //Verify if password matches
				  if (password_verify($password, $dbPassword)) {
					  //if true - Login Success
					  if ($dbVerified == Null) {
						  echo "Please check your inbox and click verify link";
					  } else {
						  setcookie("userId", $dbId, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
						  setcookie("isLoggedIn", 1, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
                          $loginSuccess = 1;
                          echo $dbId;
						  
					  }
				  } else {
					  //if false
					  echo "Please enter a valid email/password.";
				  }
			  } elseif ($userCount > 1) {
				  echo "Login error. Please contact website administrator.";
			  } else {
				  echo "Please enter a valid email/password.";
			  }
		  } else {
			  //is not a valid email address
			  echo "Please enter a valid email address";
			  $email = "";
			  $password = "";
		  }
	  }
  }
?>

