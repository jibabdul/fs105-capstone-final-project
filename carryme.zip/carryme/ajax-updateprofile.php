<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

if (isset($_POST['updateUser'])) {
    if (empty($_POST['email']) || (empty($_POST['displayName'])) || (empty($_POST['contact']))) {
        echo "Email, Display Name and Phone number are needed.";
    } else {
        $email = validateData($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid Email";
        } else {
            $name = validateData($_POST['name']);
            if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                $name = "";
                echo "Invalid Name.   ";
            } else {
                $name = $name;
                if (empty($_POST['contact'])){
                    $contact = null; 
                    $image = validateData($_POST['image']);
                    $displayName = validateData($_POST['displayName']);
                    $address = validateData($_POST['address']);
                    DB::update("users", [
                        'users_name' => strtolower($name),
                        'users_email' => strtolower($email),
                        'users_contact' => ($contact),
                        'users_displayname' => strtolower($displayName),
                        'users_address' => strtolower($address),
                        

                    ], "users_id=%i", $_POST['id']);

                    echo "User updated successfully!";
                } else {
                        $contact = validateData($_POST['contact']);
                        if (preg_match('/^[0-9]{8}$/', $contact)) {
                        $address = validateData($_POST['address']);
                        $image = validateData($_POST['image']);
                        $displayName = validateData($_POST['displayName']);
                        DB::update("users", [
                            'users_name' => strtolower($name),
                            'users_email' => strtolower($email),
                            'users_contact' => ($contact),
                            'users_displayname' => strtolower($displayName),
                            'users_address' => strtolower($address),
                            'users_img' => ($image),

                        ], "users_id=%i", $_POST['id']);

                        echo "User updated successfully!";
                     
                        } else {
                            echo "Invalid Phone Number";
                        }
                }
                
            }
        }
    }
}

?>