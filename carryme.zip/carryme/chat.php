<?php

if (isset($_GET['id'])) {
	$getId = "?id=";
	$login = '<a href=' . SITE_URL . 'logout.php class="theme_button">Log Out</a>';
	
	
} else {
	$getId = "";
	$login = "<a href='#myModal' class='theme_button' data-toggle='modal'>Login</a>";
	
}


?>