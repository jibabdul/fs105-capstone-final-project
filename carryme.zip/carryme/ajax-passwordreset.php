<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

if (isset($_POST['reset'])) {
    if ((empty($_POST['oldPassword'])) || (empty($_POST['newPassword'])) || (empty($_POST['cfmPassword']))) {
        echo "Please fill up all fields in the reset password tab";
    } else {
        $oldPassword = validateData($_POST['oldPassword']);
        $newPassword = validateData($_POST['newPassword']);
        $cfmPassword = validateData($_POST['cfmPassword']);
        if ($newPassword != $cfmPassword) {
           echo "Password mismatch!";
        } else {
            if (password_verify($oldPassword, $_POST['dbPassword'])) {
                //True
                DB::update("users", [
                    'users_password' => password_hash($newPassword, PASSWORD_DEFAULT)
                ], "users_id=%i", $_POST['id']);
                echo "Password reset successfully!";
            } else {
                //False
                echo  "Incorrect Old Password";
            }
        }
    }
}
