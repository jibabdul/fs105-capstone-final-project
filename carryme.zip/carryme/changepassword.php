<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';


if (isset($_GET['id'])) {
	$getId = "?id=";
	$login = '<a href=' . SITE_URL . 'logout.php class="theme_button">Log Out</a>';
	
	
} else {
	$getId = "";
	$login = "<a href='#myModal' class='theme_button' data-toggle='modal'>Login</a>";
	
}

if (isset($_GET['id'])) {
	$user = DB::query("SELECT * FROM users WHERE users_id=%i", $_GET['id']);
	foreach ($user as $userResults) {
		$userDisplayName = $userResults['users_displayname'];
		
	}
}


isLoggedIn();

if(isset($_GET['id'])){
  $user = DB::query("SELECT * FROM users WHERE users_id=%i", $_GET['id']);
  foreach($user as $userResults){
      $userId = $userResults['users_id'];
      $userPassword= $userResults['users_password'];
	  $userDisplayName= $userResults['users_displayname'];
	  $userImg = $userResults['users_img'];
	  if ($userImg == "") {
		$userImg = "images/team/10.jpg";
	} else {
		($userImg == $userImg);
	}
  }
  }
  
  
?> 
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<title>CarryMe - Change Password</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->
	<style>
    .required{
        color: red;
    }
    </style>
</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>


	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">
				<i class="rt-icon2-cross2"></i>
			</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform form-inline" action="./">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class="theme_button">Search</button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls with_padding">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--		
		<ul>
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div>
	<!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<section class="page_toplogo table_section ls mainpge_toplogo section_padding_25">
				<div class="container">
					<div class="row">
						<div class="col-sm-4 col-lg-3 pull-left">
							<a href="./" class="logo">
								<img src="images/carryme-logo-03.png" alt="">
							</a>
						</div>
					
					</div>
				</div>
		</div>
		</section>

		<header class="page_header header_darkgrey ms toggle_menu_left">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<!-- main nav start -->
						<nav class="mainmenu_wrapper">
							<ul class="mainmenu nav sf-menu">
							<li>
								<a href="<?php echo SITE_URL . "index.php" . $getId . $_GET['id']; ?>">Home</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "listing.php" . $getId . $_GET['id'];  ?>">Pickup</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "about.php" . $getId . $_GET['id']; ?>">About Us</a>
								</li>

								<!-- contacts -->
								<li>
									<a href="<?php echo SITE_URL . "contact.php" . $getId . $_GET['id']; ?>">Contact us</a>
								</li>


								<!-- eof contacts -->
							</ul>
						</nav>
						<!-- eof main nav -->
					</div>
					<!-- eof .header_mainmenu -->
					<div class="col-md-3 text-right">
						<span class="toggle_menu">
							<span></span>
						</span>
						<a href="<?php echo SITE_URL . 'editprofile.php?id=' . $_GET['id']; ?>" class='theme_button'><?php echo $userDisplayName ?></a>
						<span><?php echo $login ?></span>
						
					</div>
				</div>
			</div>
		</header>
		<section class="page_breadcrumbs template_breadcrumbs ds parallax">
				<div class="container-fluid">
					<div class="row">
						<div class="breadcrumbs_wrap col-lg-5 col-md-7 col-sm-8 text-right to_animate" data-animation="fadeInLeftLong">
							<div class="to_animate" data-animation="fadeInLeft" data-delay="500">
								<h2>My Profile</h2>
							</div>

							<ol class="breadcrumb greylinks to_animate" data-animation="fadeInLeft" data-delay="400">
								<li>
									<a href="<?php echo SITE_URL . 'getcarrier.php?id=' . $_GET['id'];  ?> ">
										Get Carrier
									</a>
								</li>
								<li class="active"> change password</li>
								<li >
								<a href="<?php echo SITE_URL . 'editprofile.php?id=' . $_GET['id'];  ?> " > edit profile</a>
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ls section_padding_top_100 section_padding_bottom_75 columns_margin_bottom_30">
				<div class="container">
				<form class="quote-form row topmargin_40">
					<div class="row">
						<div class="col-sm-12 text-center">
							
							<div class="framed-heading">
								<div class="isotope-item col-md-3 col-sm-6 col-xs-12">
									<div class="thumbnail">
									<p><img src="<?php echo $userImg ?>" id="output" width="200" style="height: 360px;"/></p>
										<div class="caption with_border">
											<h3>
												<?php echo $userDisplayName ?>
												
											</h3>
											
										</div>
									</div>
								</div>
							</div>
							
							
							

								<div class="col-sm-6">
								<p>
								Please fill out the following information and press the RESET button.
								</p>

									<h3 class="entry-title">Change Password</h3>

									<div class="bottommargin_10">
										<label for="oldPassword" class="sr-only">First Name
											
										</label>
										<div class="input-group">
											<i class="flaticon-avatar highlight"></i>
											<input type="password" aria-required="true" size="30" name="oldPassword" id="oldPassword" class="form-control" placeholder="Old Password">
										</div>
									</div>

									<div class="bottommargin_10">
										<label for="newPassword" class="sr-only">Display Name
											
										</label>
										<div class="input-group">
											<i class="flaticon-avatar highlight"></i>
											<input type="password" aria-required="true" size="30" name="newPassword" id="newPassword" class="form-control" placeholder="New Password">
										</div>
									</div>

									<div class="bottommargin_10">
										<label for="cfmPassword" class="sr-only">E-mail
											
										</label>
										<div class="input-group">
											<i class="flaticon-envelope highlight"></i>
											<input type="password" aria-required="true" size="30" name="cfmPassword" id="cfmPassword" class="form-control" placeholder="Confirm Password">
										</div>
									</div>

								</div>

								<div class="col-sm-6 text-center">
									<button type="submit" id="reset" name="reset" class="theme_button color2 topmargin_10">RESET</button>
								</div>
								<input type="password" name="dbPassword" id="dbPassword" value="<?php echo $userPassword ?>" style="display:none;">
								<input type="password" name="id" id="id" value="<?php echo $userId ?>" style="display:none;">
								<div class="col-sm-6 text-center">
								<?php echo $error ?>
								<span id="required"></span>
								</div>
							</form>
							<div>
						
					</div>
				</div>
			</section>

			<section class="cs section_padding_40">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://api.whatsapp.com/send?phone=6596601666&text=Hi,%20I%20want%20to%20know%20more%20about%20CarryMe." target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="fa fa-whatsapp"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Any question?</span>
									<br> Whatsapp Us!
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://www.google.com/maps/@1.2809363,103.8186308,17z" target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-house"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">258 Henderson Road</span>
									<br> Singapore, Singapore
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="media inline-block small-teaser text-left teaser-link">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round dark">
										<i class="flaticon-paper-plane"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Mon-Sat</span>
									<br> 09:00-21:00
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="mailto:carryme@email.com">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-envelope"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Send your mail at</span>
									<br>carryme@email.com
								</span>
							</a>
						</div>
					</div>
				</div>
			</section>

			<footer class="page_footer ds ms color section_padding_75 columns_margin_bottom_30">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-12">
							<img src="images/logo-light-04.png" alt="">
						</div>
					</div>
				</div>
			</footer>

			<section class="page_copyright cs main_color2 section_padding_15 columns_margin_0">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<p>&copy; CarryMe 2020
							</p>
						</div>
					</div>
				</div>
			</section>

		</div>
		<!-- eof #box_wrapper -->
		
 
	</div>
	<!-- eof #canvas -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
    $(document).ready(function(){
        $("form").submit(function(e){
            e.preventDefault(e);
        });

        $("#reset").click(function(){
            var id = $("#id").val();
			var dbPassword = $("#dbPassword").val();
            var oldPassword = $("#oldPassword").val();
            var newPassword = $("#newPassword").val();
			var cfmPassword = $("#cfmPassword").val();
			var reset = $("#reset").val();
			
            $.ajax({
                url: 'ajax-passwordreset.php', //action
                method: 'POST', //method
                data:{
                    id:id,
                    oldPassword:oldPassword,
					newPassword:newPassword,
					cfmPassword:cfmPassword,
					dbPassword:dbPassword,
					reset:reset,
					
                },
                success:function(data){
                    $("#required").text(data);
					if(data != "Password reset successfully!"){
                        $("#oldPassword").val(oldPassword);
                        $("#newPassword").val(newPassword);
            	        $("#cfmPassword").val(cfmPassword);
                    } else {
                        $("#oldPassword").val("");
                        $("#newPassword").val("");
            	        $("#cfmPassword").val("");
                    }
					    
                    
                }
            });
        });
    });
    </script>									
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>
	<script src="js/main.js"></script>


</body>

</html>