<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//define name spaces
require_once 'config/Exception.php';
require_once 'config/PHPMailer.php';
require_once 'config/SMTP.php'; 

include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

$email = "";
$error = $success = $emailError = "";

if(isset($_POST['reset'])) {  //isset = if there is.
	isNotLoggedIn();
    if(empty($_POST['email'])){
		$email = $_POST['email'];
		$error = "Please type your email.";
		
    } else {
      if(!empty($_POST['email'])){
        $email = validateData($_POST['email']);
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $emailError = "Invalid Email";
            $email = "";
            
        } else {
          $userQuery = DB::query("SELECT * FROM users WHERE users_email=%s", $email);
          $userCount = DB::count();
          if($userCount != 1){ //user exist
            $error = "Email not registered.";
            
            

        } else {
              $token = md5($_POST['email']).rand(10,9999);
              DB::update("users", [
                  'email_verification_link' => $token,
                  
              ], "users_email=%s", $_POST['email']); // ("" , []) -> "" insert to which table
              $link = "<a href=" . SITE_URL . "resetpassword.php?key=".$_POST['email']."&token=".$token."'>Click to reset password</a>";
              $mail = new PHPMailer(true);
              // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
              $mail->isSMTP();                                            //Set mailer to use SMTP
              $mail->Host       = "smtp.gmail.com";                     //Set the SMTP server to send through
              $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
              // $mail->SMTPsecure = "tls";                            //Set type of encrytion (ssl/tls)
              $mail->Username   = "muhd.nasiruddin2014@gmail.com";                     //SMTP username
              $mail->Password   = "Nasiruddin2014";                               //SMTP password
              $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption for ssl
              $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS` , SSL is port 465

              //Recipients
              $mail->setFrom("muhd.nasiruddin2014@gmail.com", "CarryMe");
              $mail->addAddress($_POST['email'] , $_POST['name']);     //Add a recipient
           
              $mail->IsHTML(true);
              $mail->Subject = "Password Recovery";
              $mail->Body = 'We received instruction to reset your email.<br>
              Please ignore this email if you do not request for the password recovery.<br>
              Please click here to reset password '.$link.'' ;
              // $mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';
              if ($mail->send()){
                $success = "<h3>Registration Successful. Please check your email and click on the link to verify. </h3>";
                // echo 'Message has been sent';

              } else {;
                echo "Message could not be sent. Mailer Error:{$mail->ErrorInfo}";          // ";
              }
              $mail -> smtpCLose();
           
          }
      }
    }   
  } 
}
  

  

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<style>
	.error {
		color: red;
	}
</style>

<head>
	<title>CarryMe - About Us</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!-- Login Modal HTML -->
	<!-- <div class="modal fade"> -->
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Login to</h4><br>
				<img src="images/carryme-logo-03.png" alt=""><br>
				<a href="http://localhost:8888/carryme/index.php" class="close">&times;</a>

			</div>
			<div class="modal-body">
				<form action="<?php echo htmlspecialchars(SITE_URL . "requestpassword.php"); ?>" method="post">
				<div class="form-group">
						<p> Please type in your email <br> to retrieve password.
					</div>
					<div class="form-group">
						<i class="fa fa-user"></i>
						<input type="text" class="form-control" placeholder="Email" id="email" name="email">
					</div>
					<div class="form-group">
						<input type="submit" id="reset" name="reset" class="btn btn-primary btn-block btn-lg" value="Retrieve Password">
					</div>
				</form>
				<p><span class="error"><?php echo $error ?></span></p>
			</div>
		</div>
	</div>
	<!-- </div>    -->
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
	<?php
	if($error != ""){
		echo 'swal("Opps....", "'. $error .'", "error");';
	}
	if($success != ""){
		echo 'swal("Email Sent!", "Please check your email to change password", "success");';
	}
	?>
	</script>

</body>

</html>