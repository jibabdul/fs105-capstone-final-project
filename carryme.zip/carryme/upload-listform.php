<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

if (isset($_POST['getCarrier'])) {
    if ((empty($_POST['itemName'])) || (empty($_POST['weight'])) || (empty($_POST['length'])) 
    || (empty($_POST['location'])) || (empty($_POST['destination'])) || (empty($_POST['date'])) 
    || (empty($_POST['time'])) || (empty($_POST['pickup'])) || (empty($_POST['dropdown'])) 
    || (empty($_POST['fee'])) || (empty($_POST['remarks']))) {

        $error = "Please fill up all field";

    } else {
        $itemName = validateData($_POST['itemName']);
        $weight = validateData($_POST['weight']);
        $length = validateData($_POST['length']);
        $location = validateData($_POST['location']);
        $destination = validateData($_POST['destination']);
        $date = validateData($_POST['date']);
        $time = validateData($_POST['time']);
        $pickup = validateData($_POST['pickup']);
        $dropdown= validateData($_POST['dropdown']);
        $fee = validateData($_POST['fee']);
        $remarks = validateData($_POST['remarks']);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $itemName)) {
            $itemNameError = "Invalid Name. Letters only   ";
        } else {
            $itemName = $itemName;
            $itemName1 = 1;
        }
        if (!preg_match("/^[A-Za-z0-9 ]*$/", $location)) {
            $locationError = "Invalid location, Letters and numbers only";
            
        } else {
            $location = $location;
            $location1 = 1;
        }
        if (!preg_match("/^[A-Za-z0-9 ]*$/", $destination)) {
            $destinationError = "Invalid destination, Letters and numbers only";
            
        } else {
            $destination = $destination;
            $destination1 = 1;
        }
        if (!preg_match("/^[a-zA-Z-' ]*$/", $pickup)) {
            $pickupError = "Invalid   ";
        } else {
            if($pickup == "Fix"){
                $pickup = 1;
                $pickup1 = 1;
            } else {
                $pickup = 0;
                $pickup1 = 1;
            }
           
        }
        if (!preg_match("/^[a-zA-Z-' ]*$/", $dropdown)) {
            $dropdownError = "Invalid";
        } else {
            if($dropdown == "Fix"){
                $dropdown = 1;
                $dropdown1 = 1;
            } else {
                $dropdown = 0;
                $dropdown1 = 1;
            }
           
        }
        if (!preg_match("/^[A-Za-z0-9 ]*$/", $remarks)) {
            $remarksError = "Invalid remarks, Letters and numbers only";
            
        } else {
            $remarks = $remarks;
            $remarks1 = 1;
        }
        if (!preg_match('/^([0-9.]+)$/', $weight)) {
            $weightError = "Invalid weight. Numbers only";
            
        } else {
            $weight = $weight;
            $weight1 = 1;
        }
        if (!preg_match('/^([0-9.]+)$/', $length)) {
            $lengthError = "Invalid length. Numbers only";
            
        } else {
            $length = $length;
            $length1 = 1;
        }
        if (!preg_match('/^([0-9.]+)$/', $fee)) {
            $feeError = "Invalid fee. Numbers only";
            
        } else {
            $fee = $fee;
            $fee1 = 1;
        }
        if (preg_match(
            '~^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$~',
            $date)) {

            $dateError = "Invalid fee. Numbers only";
            
        } else {
            $date = $date;
            $date1 = 1;
        }
        if (isset($_POST['check'])){
            if (($itemName1 == 1) || ($length1 == 1) || ($weight1 == 1) || ($location1 == 1) 
        || ($destination1 == 1) || ($remarks1 == 1) || ($pickup1 == 1)|| ($dropdown1 == 1) 
        || ($date1 == 1) || ($fee1 == 1)) {
            DB::insert("item", [
                'item_name' => strtolower($name),
                'item_length' => strtolower($email),
                'item_weight' => ($contact),
                'item_location' => strtolower($displayName),
                'item_destination' => strtolower($address),
                'item_remarks' => strtolower($name),
                'item_pickup' => strtolower($email),
                'item_delivery' => ($contact),
                'item_date' => strtolower($displayName),
                'item_time' => strtolower($address),
                'item_fee' => strtolower($address),
                

            ], "users_id=%i", $_GET['id']);

            $error = "Item submitted successfully!";
        } else {
            $error = "There is something wrong, please try again.";
        }
        

        } else {
            $error = "Please tick the checkbox.";
        }
        

    }
}


//         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//             echo "Invalid Email";
//         } else {
//             $name = validateData($_POST['name']);
//             if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
//                 $name = "";
//                 echo "Invalid Name.   ";
//             } else {
//                 $name = $name;
//                 if (empty($_POST['contact'])){
//                     $contact = null; 
//                     $image = validateData($_POST['image']);
//                     $displayName = validateData($_POST['displayName']);
//                     $address = validateData($_POST['address']);
//                     DB::update("users", [
//                         'users_name' => strtolower($name),
//                         'users_email' => strtolower($email),
//                         'users_contact' => ($contact),
//                         'users_displayname' => strtolower($displayName),
//                         'users_address' => strtolower($address),
//                         'users_img' => ($image),

//                     ], "users_id=%i", $_POST['id']);

//                     echo "User updated successfully!";
//                 } else {
//                         $contact = validateData($_POST['contact']);
//                         if (preg_match('/^([0-9.]+)$/', $contact)) {
//                         $address = validateData($_POST['address']);
//                         $image = validateData($_POST['image']);
//                         $displayName = validateData($_POST['displayName']);
//                         DB::update("users", [
//                             'users_name' => strtolower($name),
//                             'users_email' => strtolower($email),
//                             'users_contact' => ($contact),
//                             'users_displayname' => strtolower($displayName),
//                             'users_address' => strtolower($address),
//                             'users_img' => ($image),

//                         ], "users_id=%i", $_POST['id']);

//                         echo "User updated successfully!";
                     
//                         } else {
//                             echo "Invalid Phone Number";
//                         }
//                 }
                
//             }
//         }
//     }
// }

?>