<?php
include 'config/config.php';
include 'config/functions.php';
include 'config/db.php';

isNotLoggedIn();

$email = $password = $error = $loginSuccess = "";


	if (isset($_POST['signIn'])) {
		if (empty($_POST['email']) || empty($_POST['password'])) {
			$error = "Please enter your email & password";
		} else {
			$email = validateData($_POST['email']);
			$password = validateData($_POST['password']);

			//validate if email is legit
			if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
				//is a valid email address
				$userQuery = DB::query("SELECT * FROM users WHERE users_email=%s", $email);
				$userCount = DB::count();
				if ($userCount == 1) { //user exist
					foreach ($userQuery as $userResult) {
						$dbId = $userResult['users_id'];
						$dbPassword = $userResult['users_password'];
						$dbVerified = $userResult['email_verified_at'];
					}
					//Verify if password matches
					if (password_verify($password, $dbPassword)) {
						//if true - Login Success
						if ($dbVerified == Null) {
							$error = "Please check your inbox and click verify link";
						} else {
							setcookie("userId", $dbId, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
							setcookie("isLoggedIn", 1, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
							$loginSuccess = 1;
							header('Location: ' . SITE_URL . 'editprofile.php?id=' . $userResult['users_id'] . '');
						}
					} else {
						//if false
						$error = "Please enter a valid email/password.";
					}
				} elseif ($userCount > 1) {
					$error = "Login error. Please contact website administrator.";
				} else {
					$error = "Please enter a valid email/password.";
				}
			} else {
				//is not a valid email address
				$error = "Please enter a valid email address";
				$email = "";
				$password = "";
			}
		}
	}

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<style>
    .error{
        color: red;
    }
    </style>
<head>
	<title>CarryMe - About Us</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!-- Login Modal HTML -->
	<!-- <div class="modal fade"> -->
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Login to</h4><br>
				<img src="images/carryme-logo-03.png" alt=""><br>
				<a href="http://localhost:8888/carryme/index.php" class="close">&times;</a>

			</div>
			<div class="modal-body">
				<form action="<?php echo htmlspecialchars(SITE_URL . "login.php"); ?>" method="post">
					<div class="form-group">
						<i class="fa fa-user"></i>
						<input type="email" class="form-control" placeholder="Email" required="required" name="email">
					</div>
					<div class="form-group">
						<i class="fa fa-lock"></i>
						<input type="password" class="form-control" placeholder="Password" required="required" name="password">
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary btn-block btn-lg" value="Login" name="signIn">
					</div>
				</form>
				<p><span class="error"><?php echo $error ?></span></p>
			</div>
			<div class="modal-footer">
				<a href="#">Forgot Password?</a>
			</div>
		</div>
	</div>
	<!-- </div>    -->
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
		<?php
		
		if (isset($_GET['success-verified']) && $_GET['success-verified'] == 1) {
			echo 'swal("Email Verified", "Please Login", "success");';
		} elseif (isset($_GET['already-verified']) && $_GET['already-verified'] == 1) {
			echo 'swal("Email already beend verified", "Please Login", "warning");';
		} elseif (isset($_GET['not-verified']) && $_GET['not-verified'] == 1) {
			echo 'swal("Email Not Register", "Please register first", "error");';
		} else if (isset($_GET['reset-successful']) == 1){
			echo 'swal("Reset Successful!", "Please Login", "success");';
		} else {
			echo "";
		}
		?>
	</script>
</body>

</html>