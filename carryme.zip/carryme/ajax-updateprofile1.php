<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

if (isset($_POST['updateUser'])) {
    if (empty($_POST['email']) || (empty($_POST['name'])) || (empty($_POST['message']))) {
        echo "Name, email and comments are needed.";
    } else {
        $email = validateData($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid Email";
        } else {
            $name = validateData($_POST['name']);
            if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                $name = "";
                echo "Invalid Name.   ";
                
            } else {
                $name = $name;
                $message = validateData($_POST['message']);
                        DB::insert("inbox", [
                        'inbox_name' => strtolower($name),
                        'inbox_email' => strtolower($email),
                        'inbox_remarks' => ($message),
                                              

                        ]);
                    echo "We have received your feedbacks. We will reached out to you in 3 working days.";
                } 
                
            }
        }
}


?>