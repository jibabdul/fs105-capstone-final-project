<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';



// if (isset($_GET['id'])) {
// 	$user = DB::query("SELECT * FROM users WHERE users_id=%i", $_GET['id']);
// 	foreach ($user as $userResults) {
// 		$userDisplayName = $userResults['users_displayname'];

// 	}
// }




if (isset($_GET['item'])) {
	$item = DB::query("SELECT * FROM items WHERE item_id=%i", $_GET['item']); // retrieve data from database  * FROM if number %i if string %s can put both AND
	foreach ($item as $itemResults) {
		$item_name = $itemResults['item_name'];
		$item_location = $itemResults['item_location'];
		$item_weight = $itemResults['item_weight'];
		$item_length = $itemResults['item_length'];
		$item_destination = $itemResults['item_destination'];
		$item_date = $itemResults['item_date'];
		$item_time = $itemResults['item_time'];
		$item_pickup = $itemResults['item_pickup'];
		$item_delivery = $itemResults['item_delivery'];
		$item_setfee = $itemResults['item_setfee'];
		$item_img = $itemResults['item_img'];
		$item_remark = $itemResults['item_remark'];
		$users_id = $itemResults['users_id'];
		if (($item_pickup == 1) && ($item_delivery == 1)) {
			$item_schedule = "Fix";
		} else {
			$item_schedule = "Flexible";
		}
	}
}
if (isset($_GET['item'])) {
	$user = DB::query("SELECT * FROM users WHERE users_id=%i", $users_id);
	foreach ($user as $userResults) {
		$userDisplayName = $userResults['users_displayname'];
		$userImg = $userResults['users_img'];
		$userName = $userResults['users_name'];
		$userJoinDate = $userResults['email_verified_at'];
		$userEmail = $userResults['users_email'];
		$userContact = $userResults['users_contact'];
	}
}

if (isset($_GET['id'])) {
	$profile = '<a href=' .  SITE_URL . 'editprofile.php?id=' . $_GET['id'] . ' class="theme_button"> ' .   $userDisplayName . '</a>';
	$login = '<a href=' . SITE_URL . 'logout.php class="theme_button">Log Out</a>';
	$userDisplayNameMirror = $userDisplayName;
} else {
	$getId = "";
	$login = "<a href='#myModal' class='theme_button' data-toggle='modal'>Login</a>";
}





?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<title>CarryMe - Item Details</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->


</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>


	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">
				<i class="rt-icon2-cross2"></i>
			</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform form-inline" action="./">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class="theme_button">Search</button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls with_padding">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--		
		<ul>
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div>
	<!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<section class="page_toplogo table_section ls mainpge_toplogo section_padding_25">
				<div class="container">
					<div class="row">
						<div class="col-sm-4 col-lg-3 pull-left">
							<a href="./" class="logo">
								<img src="images/carryme-logo-03.png" alt="">
							</a>
						</div>

					</div>
				</div>
		</div>
		</section>

		<header class="page_header header_darkgrey ms toggle_menu_left">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<!-- main nav start -->
						<nav class="mainmenu_wrapper">
							<ul class="mainmenu nav sf-menu">
								<li>
									<a href="<?php echo SITE_URL . "index.php" . $getId . $_GET['id']; ?>">Home</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "listing.php" . $getId . $_GET['id'];  ?>">Pickup</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "about.php" . $getId . $_GET['id']; ?>">About Us</a>
								</li>

								<!-- contacts -->
								<li>
									<a href="<?php echo SITE_URL . "contact.php" . $getId . $_GET['id']; ?>">Contact us</a>
								</li>
								<!-- eof contacts -->
							</ul>
						</nav>
						<!-- eof main nav -->
					</div>
					<!-- eof .header_mainmenu -->
					<div class="col-md-3 text-right">
						<span class="toggle_menu">
							<span></span>
						</span>
						<span><?php echo $profile ?></span>
						<span><?php echo $login ?></span>
						<!-- <a href="#myModal" class="theme_button" data-toggle="modal">Login</a> -->
					</div>
				</div>
			</div>
		</header>
		<!-- Login Modal HTML -->
		<div id="myModal" class="modal fade">
			<div class="modal-dialog modal-login">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Login to</h4><br>
						<img src="images/carryme-logo-03.png" alt=""><br>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<form id=formLogin>
							<div class="form-group">
								<i class="fa fa-user"></i>
								<input type="text" class="form-control" placeholder="Email" id="email" name="email">
							</div>
							<div class="form-group">
								<i class="fa fa-lock"></i>
								<input type="password" class="form-control" placeholder="Password" id="password" name="password">
							</div>
							<div class="form-group">
								<input type="submit" class="btn btn-primary btn-block btn-lg" name="signIn" id="signIn" value="Login">
							</div>
						</form>
						<span id="required"></span>
					</div>
					<div class="modal-footer">
						<a href="#">Forgot Password?</a>
					</div>
				</div>
			</div>
		</div>

		
	
		<section class="page_breadcrumbs template_breadcrumbs ds parallax">
			<div class="container-fluid">
				<div class="row">
					<div class="breadcrumbs_wrap col-lg-5 col-md-7 col-sm-8 text-right to_animate" data-animation="fadeInLeftLong">
						<div class="to_animate" data-animation="fadeInLeft" data-delay="500">
							<h2>Product Details</h2>
						</div>


					</div>
				</div>
			</div>
		</section>


		<section class="ls section_padding_top_100 section_padding_bottom_75">
			<div class="container">
				<div class="row">


					<div class="col-sm-7 col-md-8 col-lg-8">


						<div class="isotope_container isotope row masonry-layout columns_margin_top_0 columns_margin_bottom_30">

							<div class="isotope-item col-lg-12 col-md-12 col-sm-12 kitchen">
								<div class="vertical-item content-padding gallery-item gallery-extended-item with_border text-center">
									<div class="item-media">
										<img src="<?php echo $item_img ?> " style="height:400px;" alt="">
									</div>
									<div class="item-content">
										<h3 class="entry-title margin_0">
											<?php echo $item_name ?>

										</h3>
									</div>
									<div class="row">
										<div class="columnNew" style="float:left;padding:30px;text-align:left;width:50%;">
											<p>Item Weight: <?php echo $item_weight ?> kg</p>
											<p>Item Length: <?php echo $item_length ?> m</p>
											<p>Pickup From: <?php echo $item_location ?> </p>
											<p>Deliver To: <?php echo $item_destination ?> </p>
										</div>
										<div class="columnNew" style="float:left;padding:30px;width:50%;text-align:left;">
											<p>Pickup Date: <?php echo $item_date ?> </p>
											<p>Pickup Time: <?php echo $item_time ?> </p>
											<p>Schedule: <?php echo $item_schedule ?> </p>
											<p>Status: </p>

										</div>

									</div>
									<p>
										<h3>Fee Offer: <strong> $<?php echo $item_setfee ?> </strong></h3>
									</p>
									<p>Remarks:</p>
									<p> <?php echo $item_remark ?></p>


								</div>
							</div>

						</div>
						<!-- eof .isotope_container.row -->




					</div>
					<!--eof .col-sm-8 (main content)-->


					<!-- sidebar -->
					<aside class="col-sm-5 col-md-4 col-lg-4">



						<div class="widget widget_text">

							<h1 class="entry-title"><?php echo $userDisplayName ?></h1>
							<div class="textwidget">
								<img src="<?php echo $userImg ?>" alt="" class="alignleft" style="height:200px" /> <br> <br><br><br><br><br><br><br> Name: <?php echo $userName ?> <br>
								Join since: <?php echo $userJoinDate ?> <br>
							</div>
						</div>

						
						<div class="with_border color_border with_padding" style="text-align: center;">
						<?php 
						if (!isset($_GET['id'])) {
						
							echo '<a href="#myModal" class="theme_button color2" data-toggle="modal">Please Login for <br> contact number</a>';

						}  else {

							echo '<a href="" . $userContact  class="theme_button color2" data-toggle="modal"> Contact Now! <br> ' . $userContact . '</a>';

						}   
						

						?>

						</div>


					</aside>
					<!-- eof aside sidebar -->

				</div>

			</div>
		</section>

		<section class="cs section_padding_40">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<a class="media inline-block small-teaser text-left teaser-link" href="https://api.whatsapp.com/send?phone=6596601666&text=Hi,%20I%20want%20to%20know%20more%20about%20CarryMe." target="_blank">
							<span class="media-left media-middle">
								<span class="teaser_icon border_icon round">
									<i class="fa fa-whatsapp"></i>
								</span>
							</span>
							<span class="media-body media-middle semibold">
								<span class="bold grey">Any question?</span>
								<br> Whatsapp Us!
							</span>
						</a>
					</div>
					<div class="col-md-3 col-sm-6">
						<a class="media inline-block small-teaser text-left teaser-link" href="https://www.google.com/maps/@1.2809363,103.8186308,17z" target="_blank">
							<span class="media-left media-middle">
								<span class="teaser_icon border_icon round">
									<i class="flaticon-house"></i>
								</span>
							</span>
							<span class="media-body media-middle semibold">
								<span class="bold grey">258 Henderson Road</span>
								<br> Singapore, Singapore
							</span>
						</a>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="media inline-block small-teaser text-left teaser-link">
							<span class="media-left media-middle">
								<span class="teaser_icon border_icon round dark">
									<i class="flaticon-paper-plane"></i>
								</span>
							</span>
							<span class="media-body media-middle semibold">
								<span class="bold grey">Mon-Sat</span>
								<br> 09:00-21:00
							</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<a class="media inline-block small-teaser text-left teaser-link" href="mailto:carryme@email.com">
							<span class="media-left media-middle">
								<span class="teaser_icon border_icon round">
									<i class="flaticon-envelope"></i>
								</span>
							</span>
							<span class="media-body media-middle semibold">
								<span class="bold grey">Send your mail at</span>
								<br>carryme@email.com
							</span>
						</a>
					</div>
				</div>
			</div>
		</section>

		<footer class="page_footer ds ms color section_padding_75 columns_margin_bottom_30">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-12">
						<img src="images/logo-light-04.png" alt="">
					</div>
				</div>
			</div>
		</footer>

		<section class="page_copyright cs main_color2 section_padding_15 columns_margin_0">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<p>&copy; CarryMe 2020
						</p>
					</div>
				</div>
			</div>
		</section>

	</div>
	<!-- eof #box_wrapper -->


	</div>
	<!-- eof #canvas -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script>
		$(document).ready(function() {


			$("#signIn").click(function() {
				$("#formLogin").submit(function(e) {
					e.preventDefault(e);
				});

				var email = $("#email").val();
				var password = $("#password").val();
				var signIn = $("#signIn").val();

				$.ajax({
					url: 'ajax-login.php', //action
					method: 'POST', //method
					data: {
						email: email,
						password: password,
						signIn: signIn
					},
					success: function(data) {

						if (data >= 0) {

							window.location.href = "<?php echo SITE_URL . 'editprofile.php?id=' ?>" + data;

						} else {
							$("#required").text(data);
							$("#password").val("");
						}




					}
				});
			});
		});
	</script>
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
		<?php
		if ($error != "") {
			echo 'swal("Please Login"' . $error . '", "error");';
		}
		if ($success != "") {
			echo 'swal("Email Sent!", "Please check your email to change password", "success");';
		}
		?>
	</script>
	

</body>

</html>