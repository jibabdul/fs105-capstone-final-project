<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

if (isset($_GET['id'])) {
	$getId = "?id=";
	$login = '<a href=' . SITE_URL . 'logout.php class="theme_button">Log Out</a>';
	
	
} else {
	$getId = "";
	$login = "<a href='#myModal' class='theme_button' data-toggle='modal'>Login</a>";
	
}
if (isset($_GET['id'])) {
	$user = DB::query("SELECT * FROM users WHERE users_id=%i", $_GET['id']);
	foreach ($user as $userResults) {
		$userDisplayName = $userResults['users_displayname'];
		
	}
}

isLoggedIn();

$itemName = $weight = $length = $location = $destination = $date = $time = $pickup = $dropdown = $fee = $remarks = "";
$itemName1 = $weight1 = $length1 = $location1 = $destination1 = $date1 = $time1 = $pickup1 = $dropdown1 = $fee1 = $remarks1 = "";

if (isset($_POST['getCarrier'])) {
	if ((empty($_POST['itemName'])) || (empty($_POST['weight'])) || (empty($_POST['length']))
		|| (empty($_POST['location'])) || (empty($_POST['destination'])) || (empty($_POST['date']))
		|| (empty($_POST['time'])) || (empty($_POST['pickup'])) || (empty($_POST['dropdown']))
		|| (empty($_POST['fee'])) || (empty($_POST['remarks']))) {

		$error = "Please fill up all field";
	} else {
		$itemName = validateData($_POST['itemName']);
		$weight = validateData($_POST['weight']);
		$length = validateData($_POST['length']);
		$location = validateData($_POST['location']);
		$destination = validateData($_POST['destination']);
		$date = validateData($_POST['date']);
		$time = validateData($_POST['time']);
		$pickup = validateData($_POST['pickup']);
		$dropdown = validateData($_POST['dropdown']);
		$fee = validateData($_POST['fee']);
		$remarks = validateData($_POST['remarks']);
		$fileToUpload = validateData($_POST['fileToUpload']);
		$target_dir = "uploads/";
		$target_file = basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
		$target_file = $target_dir . uniqid(rand(), true) . '.' . $imageFileType;
		// Check if image file is a actual image or fake image

		$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if ($check === false) {
			$picError = "File is not an image.";
			$uploadOk = 0;
		} else {
			if (
				$imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif"
			) {
				$picError = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
			} else {
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					$picError = "";
					$fileToUpload1 = 1;
				} else {
					$picError = "Sorry, there was an error uploading your file.";
				}
			}
		}


		if (!preg_match("/^[a-zA-Z-' ]*$/", $itemName)) {
			$itemNameError = "Invalid Name. Letters only   ";
		} else {
			$itemName = $itemName;
			$itemName1 = 1;
		}
		if (!preg_match("/^[A-Za-z0-9 ]*$/", $location)) {
			$locationError = "Invalid location, Letters and numbers only";
		} else {
			$location = $location;
			$location1 = 1;
		}
		if (!preg_match("/^[A-Za-z0-9 ]*$/", $destination)) {
			$destinationError = "Invalid destination, Letters and numbers only";
		} else {
			$destination = $destination;
			$destination1 = 1;
		}
		if (!preg_match("/^[a-zA-Z-' ]*$/", $pickup)) {
			$pickupError = "Invalid   ";
		} else {
			if ($pickup == "fix") {
				$pickup = 1;
				$pickup1 = 1;
			} else {
				$pickup = 0;
				$pickup1 = 1;
			}
		}
		if (!preg_match("/^[a-zA-Z-' ]*$/", $dropdown)) {
			$dropdownError = "Invalid";
		} else {
			if ($dropdown == "fix") {
				$dropdown = 1;
				$dropdown1 = 1;
			} else {
				$dropdown = 0;
				$dropdown1 = 1;
			}
		}
		if (!preg_match("/^[A-Za-z0-9 ]*$/", $remarks)) {
			$remarksError = "Invalid remarks, Letters and numbers only";
		} else {
			$remarks = $remarks;
			$remarks1 = 1;
		}
		if (!preg_match('/^([0-9.]+)$/', $weight)) {
			$weightError = "Invalid weight. Numbers only";
		} else {
			$weight = $weight;
			$weight1 = 1;
		}
		if (!preg_match('/^([0-9.]+)$/', $length)) {
			$lengthError = "Invalid length. Numbers only";
		} else {
			$length = $length;
			$length1 = 1;
		}

		if (!preg_match('/^([0-9.]+)$/', $fee)) {
			$feeError = "Invalid fee. Numbers only";
		} else {
			$fee = $fee;
			$fee1 = 1;
		}
		if (preg_match(
			'~^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$~',
			$date
		)) {

			$dateError = "Invalid fee. Numbers only";
		} else {
			$date = $date;
			$date1 = 1;
		}
		if (isset($_POST['check'])) {
			if (($itemName1 == 1) && ($length1 == 1) && ($weight1 == 1) && ($location1 == 1)
				&& ($destination1 == 1) && ($remarks1 == 1) && ($pickup1 == 1) && ($dropdown1 == 1)
				&& ($date1 == 1) && ($fee1 == 1)) {
				DB::insert("items", [
					'item_name' => strtolower($itemName),
					'item_length' => strtolower($length),
					'item_weight' => ($weight),
					'item_location' => strtolower($location),
					'item_destination' => strtolower($destination),
					'item_remark' => strtolower($remarks),
					'item_pickup' => strtolower($pickup),
					'item_delivery' => ($dropdown),
					'item_date' => strtolower($date),
					'item_time' => strtolower($time),
					'item_setfee' => strtolower($fee),
					'item_img' => $target_file,
					'users_id' => $_GET['id'],
					


				]);
				$error = "Item submitted successfully";
				$itemName = $weight = $length = $location = $destination = $date = $time = $pickup = $dropdown = $fee = $remarks = "";
				$picError ="";
			} else {
				$error = "";
			}
		} else {
			$error = "Please tick the checkbox.";
		}
	}
}


?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<title>CarryMe - Find Carrier Now</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->
	<style>
		.error {
			color: red;
		}
	</style>
</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>


	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">
				<i class="rt-icon2-cross2"></i>
			</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform form-inline" action="./">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class="theme_button">Search</button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls with_padding">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--		
		<ul>
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div>
	<!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<section class="page_toplogo table_section ls mainpge_toplogo section_padding_25">
				<div class="container">
					<div class="row">
						<div class="col-sm-4 col-lg-3 pull-left">
							<a href="./" class="logo">
								<img src="images/carryme-logo-03.png" alt="">
							</a>
						</div>
						
					</div>
				</div>
		</div>
		</section>

		<header class="page_header header_darkgrey ms toggle_menu_left">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<!-- main nav start -->
						<nav class="mainmenu_wrapper">
							<ul class="mainmenu nav sf-menu">
							<li>
								<a href="<?php echo SITE_URL . "index.php" . $getId . $_GET['id']; ?>">Home</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "listing.php" . $getId . $_GET['id'];  ?>">Pickup</a>
								</li>

								<li>
									<a href="<?php echo SITE_URL . "about.php" . $getId . $_GET['id']; ?>">About Us</a>
								</li>

								<!-- contacts -->
								<li>
									<a href="<?php echo SITE_URL . "contact.php" . $getId . $_GET['id']; ?>">Contact us</a>
								</li>
								<!-- eof contacts -->
							</ul>
						</nav>
						<!-- eof main nav -->
					</div>
					<!-- eof .header_mainmenu -->
					<div class="col-md-3 text-right">
						<span class="toggle_menu">
							<span></span>
						</span>
						<a href="<?php echo SITE_URL . 'editprofile.php?id=' . $_GET['id']; ?>" class='theme_button'><?php echo $userDisplayName ?></a>
						<span><?php echo $login ?></span>
						
					</div>
				</div>
			</div>
		</header>
		<!-- Login Modal HTML -->
		<div id="myModal" class="modal fade">
			<div class="modal-dialog modal-login">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Login to</h4><br>
						<img src="images/carryme-logo-03.png" alt=""><br>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<form>
							<div class="form-group">
								<i class="fa fa-user"></i>
								<input type="text" class="form-control" placeholder="Email" id="email" name="email">
							</div>
							<div class="form-group">
								<i class="fa fa-lock"></i>
								<input type="password" class="form-control" placeholder="Password" id="password" name="password">
							</div>
							<div class="form-group">
								<input type="submit" class="btn btn-primary btn-block btn-lg" name="signIn" id="signIn" value="Login">
							</div>
						</form>
						<span id="required"></span>
					</div>
					<div class="modal-footer">
						<a href="#">Forgot Password?</a>
					</div>
				</div>
			</div>
		</div>

		<section class="page_breadcrumbs template_breadcrumbs ds parallax">
			<div class="container-fluid">
				<div class="row">
					<div class="breadcrumbs_wrap col-lg-5 col-md-7 col-sm-8 text-right to_animate" data-animation="fadeInLeftLong">
						<div class="to_animate" data-animation="fadeInLeft" data-delay="500">
							<h2>My Profile</h2>
						</div>

						<ol class="breadcrumb greylinks to_animate" data-animation="fadeInLeft" data-delay="400">
							<li class="active"> get carrier</li>
							<li>
								<a href="<?php echo SITE_URL . 'changepassword.php?id=' . $_GET['id'];  ?> "> change password</a>
							</li>
							<li>
								<a href="<?php echo SITE_URL . 'editprofile.php?id=' . $_GET['id'];  ?> "> edit profile</a>
							</li>
						</ol>
					</div>
				</div>
			</div>
		</section>
		<!-- Login Modal HTML -->
		<div id="myModal" class="modal fade">
			<div class="modal-dialog modal-login">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Login to</h4><br>
						<img src="images/carryme-logo-03.png" alt=""><br>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<form action="/examples/actions/confirmation.php" method="post">
							<div class="form-group">
								<i class="fa fa-user"></i>
								<input type="text" class="form-control" placeholder="Username" required="required">
							</div>
							<div class="form-group">
								<i class="fa fa-lock"></i>
								<input type="password" class="form-control" placeholder="Password" required="required">
							</div>
							<div class="form-group">
								<input type="submit" class="btn btn-primary btn-block btn-lg" value="Login">
							</div>
						</form>

					</div>
					<div class="modal-footer">
						<a href="#">Forgot Password?</a>
					</div>
				</div>
			</div>
		</div>
		<section class="ls section_padding_top_100 section_padding_bottom_75 columns_margin_bottom_30">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<div class="isotope-item col-lg-4 col-md-6 col-sm-12 kitchen">
							<div class="vertical-item gallery-item content-absolute vertical-center text-center">
								<div class="item-media">
									<img src="images/gallery/01.jpg" style="height: 234px;" id="output" alt="">
									<div class="media-links">
										<div class="links-wrap">
											
										<form action="<?php echo htmlspecialchars(SITE_URL . "getcarrier.php?id=" .  $_GET['id']); ?>" method="post" enctype="multipart/form-data">
											<p><label for="file" style="cursor: pointer;"><u style="color:white;">Click to upload image</u> </label></p>
											<p><input type="file" accept="image/*" name="fileToUpload" id="file" onchange="loadFile(event)" style="display: none;"></p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<script>
							var loadFile = function(event) {
								var image = document.getElementById('output');
								image.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>

						<div class="framed-heading">
							<h2 class="section_header">
								List item now
							</h2>
						</div>
						<p style="max-width: fit-content;">
							Please fill out the following information and press the SUBMIT button. It is compulsory to fill entire form and as accurate as possible.
						</p><br>

						
							<p><span class="error"><?php echo $error ?></span></p>
							<p><span class="error"><?php echo $picError ?></span></p>
							<div class="form-group has-placeholder">
								<label for="itemName">Item Name:</label>
								<input type="text" class="form-control" id="itemName" name="itemName" value="<?php echo $itemName ?>" placeholder="Item Name: (Letters Only) " required>
								<span class="itemNameError"><?php echo $itemNameError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="weight">Weight (kg)</label>
								<input type="text" class="form-control" id="weight" name="weight" value="<?php echo $weight ?>"placeholder="Weight (kg): (Numbers Only)" required>
								<span class="weighteError"><?php echo $weightError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="length">Length (cm)</label>
								<input type="text" class="form-control" id="length" name="length" value="<?php echo $length ?>"placeholder="Length (cm): (Numbers Only)" required>
								<span class="lengthError"><?php echo $lengthError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="location">Location:</label>
								<input type="text" class="form-control" id="location" name="location" value="<?php echo $location ?>" placeholder="Pick up location: (Street Name. Eg: Hougang Ave 3)" required>
								<span class="locationError"><?php echo $locationError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="destination">Destination:</label>
								<input type="text" class="form-control" id="destination" name="destination" value="<?php echo $destination ?>"placeholder="Destination: (Street Name. Eg: Tampiness Ave 10" required>
								<span class="destinationError"><?php echo $destinationError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="date">Date:</label>
								<input type="date" class="form-control" id="date" name="date" value="<?php echo $date?>"placeholder="Date:" required>
								<span class="dateError"><?php echo $dateError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="time">Time:</label>
								<input type="time" class="form-control" id="time" name="time" value="<?php echo $time ?>"placeholder="Time:" required>
								<span class="timeError"><?php echo $timeError ?></span>
							</div>

							<div class="form-group">
								<select class="form-control" name="pickup" id="pickup" required>
									<option disabled="disabled" selected="selected">Pickup Schedule:</option>
									<option value="fix">Fixed Time: Date & Time as stated</option>
									<option value="flexible">Flexible: Msg for the Date & Time</option>
								</select>
								<span class="pickupError"><?php echo $pickupError ?></span>
							</div>
							<div class="form-group">
								<select class="form-control" name="dropdown" id="dropdown"  required>
									<option disabled="disabled" selected="selected">Delivery Schedule:</option>
									<option value="fix">Immediately after pickup</option>
									<option value="flexible">Flexible: Msg for the Date & Time</option>
								</select>
								<span class="dropdownError"><?php echo $dropdownError ?></span>
							</div>
							<div class="form-group has-placeholder">
								<label for="fee">Set Fee:</label>
								<input type="text" class="form-control" id="fee" name="fee" value="<?php echo $fee ?>"placeholder="Set Fee: (Numbers Only) " required>
								<span class="feeError"><?php echo $feeError ?></span>
							</div>
							<div class="form-group">
								<textarea class="form-control" rows="3" id="remarks" name="remarks" placeholder="Message"><?php echo $remarks ?></textarea>
								<span class="remarksError"><?php echo $remarksError ?></span>
							</div>
							<div class="checkbox">
								<input type="checkbox" name="check" id="checkbox_2" checked="">
								<label for="checkbox_2">I submit this to be true and ready to be carried out</label>
							</div>
							<button type="submit" name="getCarrier" id="getCarrier" class="theme_button color2">Get Carrier Now!</button>
						</form>
		</section>

		<section class="cs section_padding_40">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://api.whatsapp.com/send?phone=6596601666&text=Hi,%20I%20want%20to%20know%20more%20about%20CarryMe." target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="fa fa-whatsapp"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Any question?</span>
									<br> Whatsapp Us!
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="https://www.google.com/maps/@1.2809363,103.8186308,17z" target="_blank">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-house"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">258 Henderson Road</span>
									<br> Singapore, Singapore
								</span>
							</a>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="media inline-block small-teaser text-left teaser-link">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round dark">
										<i class="flaticon-paper-plane"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Mon-Sat</span>
									<br> 09:00-21:00
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<a class="media inline-block small-teaser text-left teaser-link" href="mailto:carryme@email.com">
								<span class="media-left media-middle">
									<span class="teaser_icon border_icon round">
										<i class="flaticon-envelope"></i>
									</span>
								</span>
								<span class="media-body media-middle semibold">
									<span class="bold grey">Send your mail at</span>
									<br>carryme@email.com
								</span>
							</a>
						</div>
					</div>
				</div>
			</section>

			<footer class="page_footer ds ms color section_padding_75 columns_margin_bottom_30">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-12">
							<img src="images/logo-light-04.png" alt="">
						</div>
					</div>
				</div>
			</footer>

			<section class="page_copyright cs main_color2 section_padding_15 columns_margin_0">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<p>&copy; CarryMe 2020
							</p>
						</div>
					</div>
				</div>
			</section>

		</div>
		<!-- eof #box_wrapper -->
		
 
	</div>
	<!-- eof #canvas -->
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>


</body>

</html>