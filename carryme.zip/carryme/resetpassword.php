<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';


if(isset($_GET['key']) && $_GET['token']) {


$email = $_GET['key'];
$token = $_GET['token'];
  
$userQuery = DB::query("SELECT * FROM `users` WHERE `email_verification_link`='".$token."' and `users_email`='".$email."';");
$userCount = DB::count();
if($userCount == 1){
	if (isset($_POST['reset'])) {
		if ((empty($_POST['newPassword'])) || (empty($_POST['cfmPassword']))) {
			$error = "Please fill up all fields in the reset password tab";
		} else {
			$newPassword = validateData($_POST['newPassword']);
			$cfmPassword = validateData($_POST['cfmPassword']);
			if ($newPassword != $cfmPassword) {
			   $error = "Password mismatch!";
			} else {
		      			//True
					DB::update("users", [
					'users_password' => password_hash($newPassword, PASSWORD_DEFAULT)
					], "users_email=%s", $_GET['key']);

					header("Location: " . SITE_URL ."login.php?reset-successful=1 ");
				
				}
		}
	}
	
 }
} else {
	// header("Location: " SITE_URL  );
}




?>


  


<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<style>
	.error {
		color: red;
	}
</style>

<head>
	<title>CarryMe - About Us</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css" id="color-switcher-link">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!-- Login Modal HTML -->
	<!-- <div class="modal fade"> -->
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Login to</h4><br>
				<img src="images/carryme-logo-03.png" alt=""><br>
				<a href="http://localhost:8888/carryme/index.php" class="close">&times;</a>

			</div>
			<div class="modal-body">
				<form action="<?php echo htmlspecialchars(SITE_URL . "resetpassword.php?key=" . $email . "&token=" . $token . ""); ?>" method="post">
					<div class="form-group">
						<i class="flaticon-avatar highlight"></i>
						<input type="password" aria-required="true" size="30" name="newPassword" id="newPassword" class="form-control" placeholder="New Password">
					</div>
					<div class="form-group">
						<i class="flaticon-envelope highlight"></i>
						<input type="password" aria-required="true" size="30" name="cfmPassword" id="cfmPassword" class="form-control" placeholder="Confirm Password">
					</div>
					<div class="form-group">
						<input type="submit" id="reset" name="reset" class="btn btn-primary btn-block btn-lg" value="RESET">
					</div>
				</form>
				<p><span class="error"><?php echo $error ?></span></p>
			</div>
		</div>
	</div>
	<!-- </div>    -->
	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
	<?php
	if($error != ""){
		echo 'swal("Opps....", "'. $error .'", "error");';
	}
	if($success != ""){
		echo 'swal("Email Sent!", "Please check your email to change password", "success");';
		header("Location: " . SITE_URL ."login.php" );
	}
	?>
	</script>

</body>

</html>